import os
import json
import boto3

client = boto3.client('connect')


def lambda_handler(event, context):
    # TODO implement
    print(event)
    try:
        if event['category']:
          category = event['category']
        else:
            category = 'NULL'
            
        if event['sub_category']:
          sub_category = event['sub_category']
        else:
            sub_category = 'NULL'  
            
        if event['callreason']:
            callreason = event['callreason']
        else:
            callreason = 'NULL'
            
        if event['contactID']:
            ContactId = event['contactID']
        else:
            ContactId = 'NULL'

        #InstanceId = os.environ['InstanceId']
        InstanceId = event['instanceId']
            
    except Exception as err:
        print(err)

    try:
        response = client.update_contact_attributes(
        InitialContactId=ContactId,
        InstanceId=InstanceId,
        Attributes={
            'Category': category,
            'Sub-Category': sub_category,
            'Call-Reason': callreason
        }
    )
    
        return {"status":200}
    except Exception as e:
        return {"status":500}
        raise e
