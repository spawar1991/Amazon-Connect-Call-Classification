import json
import boto3
import os
import cfnresponse

def lambda_handler(event, context):
    old_bucket_name = os.environ['existingBucket']
    old_prefix = os.environ['exisingBucketPrefix']
    new_bucket_name = os.environ['newBucket']
    new_prefix = os.environ['newBucketPrefix']

    s3 = boto3.resource('s3')

    old_bucket = s3.Bucket(old_bucket_name)
    new_bucket = s3.Bucket(new_bucket_name)
    responseData = {}
    try:
        for obj in old_bucket.objects.filter(Prefix=old_prefix):
            old_source = { 'Bucket': old_bucket_name,
                           'Key': obj.key}
            # replace the prefix
            new_key = new_prefix + obj.key[len(old_prefix):]
            new_obj = new_bucket.Object(new_key)
            new_obj.copy(old_source)
        responseData['statusCode'] = 200
        cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData)
    except Exception as e:
        responseData['statusCode'] = str(e)
        cfnresponse.send(event, context, cfnresponse.FAILED, responseData)
    